# Arquitectura
Carpeta reservada para arquitectura logica, tecnica y de despliegue.
