# Gestion
Carpeta reservada para roadmap, hitos y control de cambios.
