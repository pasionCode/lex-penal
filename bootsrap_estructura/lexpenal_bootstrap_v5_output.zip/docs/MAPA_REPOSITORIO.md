# Mapa del repositorio

## Directorios
- `docs/00_gobierno`: decisiones, alcance y gobierno documental.
- `docs/01_producto`: producto, backlog y reglas funcionales.
- `docs/02_arquitectura`: arquitectura y componentes.
- `docs/03_datos`: datos y catálogos.
- `docs/04_api`: contrato API.
- `docs/05_frontend`: navegación, layout y pantallas.
- `docs/06_backend`: servicios y módulos.
- `docs/07_infraestructura`: despliegue y red.
- `docs/08_seguridad`: controles y endurecimiento.
- `docs/09_calidad`: pruebas y criterios.
- `docs/10_gestion`: roadmap y entregables.
- `docs/11_informes`: plantillas e informes.
- `docs/12_ia`: diseño del módulo IA.
- `docs/13_operacion`: runbooks y soporte.
- `docs/14_legal_funcional`: alineación con la Unidad 8.

## Regla de uso
La documentacion fija los invariantes. El codigo ejecutable implementa y prueba esa hipotesis.
